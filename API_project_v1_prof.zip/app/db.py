#pip install Flask
# pip install Flask_SQLAlchemy

from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()